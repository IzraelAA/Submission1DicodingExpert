package com.google.ai.submison1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

public class Detail_activity extends AppCompatActivity {

    public  static final String IMG_PHOTO      = "PHOTO_FILM" ;
    public static final  String NAMA_FILM      = "NAMA_FILM";
    public static final  String DESKRIPSI_FILM ="DESKRIPSI_FILM";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_activity);
        ImageView    imgPhoto =findViewById(R.id.img_item_photo);
        TextView tvName   = findViewById(R.id.tv_item_name);
        TextView tvDesc   = findViewById(R.id.tv_item_deskripsi);

        Bundle bundle = getIntent().getExtras();
        String NAMA = getIntent().getStringExtra(NAMA_FILM);
        String DESKRIPSI = getIntent().getStringExtra(DESKRIPSI_FILM);
        Integer IMG = getIntent().getIntExtra(IMG_PHOTO,0);




        tvName.setText(NAMA);
        tvDesc.setText(DESKRIPSI);
        imgPhoto.setImageResource(IMG);
        if (getSupportActionBar() != null ){
            getSupportActionBar().setTitle(NAMA);
        }

    }
}